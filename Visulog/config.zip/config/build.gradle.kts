
plugins {
    `java-library`
}

dependencies {
    testImplementation("junit:junit:4.+")
}



package up.visulog.config;

public class TestConfiguration {
    /*
    Do not forget writing tests as soon as class Configuration contains more than just getters
    (or if they or the constructor start doing something smart!).
     */
}

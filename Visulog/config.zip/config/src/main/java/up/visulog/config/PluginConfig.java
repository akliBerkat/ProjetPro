package up.visulog.config;

// TODO: define what this type should be (probably a Map: settingKey -> settingValue)
public interface PluginConfig {
}
